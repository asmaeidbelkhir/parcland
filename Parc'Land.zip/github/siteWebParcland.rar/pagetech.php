<!DOCTYPE html>
<HTML LANG="fr">
<head> 
<TITLE>
 pageconnex.html
 </TITLE>
 <STYLE type="text/css">
body {
  margin: 0;
  padding: 0;
  border: 0;
} 
.video-container {
  position: relative;
}

#vid {
  position: fixed;
  top: 0;
  left: 0;
  min-width: 100%;
  min-height: 100%;
  z-index: -1;
}

.video-container .content {
  position: relative;
  z-index: 1;
  padding: 20px;
  box-sizing: border-box;
  margin-top: 100px;
}



.hero {

  background-repeat: no-repeat;
  background-size: cover;
}

#log {
  position: fixed;
  top: 10px;
  left: 10px;
  width: 115px;
  height: 115px;
  z-index: 9999;
}

/*.hero::before {
  content: "";
  background: rgb(0 0 0 / 20%);
  width: 100vw;
  height: 100vh;
  position: absolute;
  z-index: 0;
} */

.hero header {

   z-index: 1;
  background-color: rgba(0,0,0,0.5);
  display: grid ;
  grid-template-columns: 20% 80%;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100px;
 
  max-width: 2800;
  width: 100%;
  margin: 0 auto;
  padding: 10px 16px;
  
}
.hero header menu {
  float: right;
  margin : 25px 20px ;
  padding: 0;
}
.hero header menu ul {
  list-style: none;
  padding: 0;
  display: flex;
  gap: 1em;
  color: white;
}
.hero header menu ul li {
}

.hero header menu ul li a {
  text-decoration: none;
  color: white;

}

.hero header menu .search {
      background: no-repeat url(https://cdn1.parksmedia.wdprapps.disney.com/media/layout/assets/icons/pep/search.svg);
    
    background-position: right top;
    height: 20px;
    width: 20px;
    padding: 4px 4px;
    border: 2px solid white;
    background-color: white;
    border-radius: 10%;

}
  #emplacement {  border: 4px solid white ;
}


#info{ 
 
  grid-template-columns: 20% 80%;
  
  font-size: 25pt;

        margin:100px 350px;
        color:black;
         
           border: 8px 8px 8px solid #676264 ;
           background-color: white;
           border-radius: 10%;
           box-shadow: 10px 10px 10px #676264;
           text-align: center;
           height: 70vh;
           }
      #np{   font-size: 15pt;
}      
 #enreg {    border: 2px solid black;
                         background-color: black;
                         border-radius: 10%;
                         text-align: center;
                         color: white;
 
           } 


 </STYLE>

</head>
<body>
<div class="video-container">
  <video id="vid" class="html5VideoPlayer no-media-autotrack" poster="https://cdn1.parksmedia.wdprapps.disney.com/resize/mwImage/2/1280/720/75/vision-dam/digital/parks-platform/parks-global-assets/disney-world/campaign/six-parks/walt-disney-world-six-parks-UK-16x9.jpg" autoplay="autoplay" loop="loop" muted="" src="https://cdn1.parksmedia.wdprapps.disney.com/vision-dam/digital/parks-platform/parks-global-assets/disney-world/campaign/six-parks/walt-disney-world-six-parks-UK-loop-video-1280x720.mp4"></video>

  <div class="content">

    <div class="hero" id="hero">
      <header>
       <script src="./script.js">
          const searchBtn = document.getElementById("search");
         
         searchBtn.addEventListener("click", function test(event) {
          alert("ok");
          //event.preventDefault(); // Empêche le formulaire de se soumettre
          document.getElementById("emplacement").style.display = "block";
       //const searchBtn = document.getElementById("emplacement");
       //searchBtn.style.display = "block" ;
    
       //const searchQuery = document.querySelector("input[name='searchQuery']").value;
        //alert("Vous avez cherché : " + searchQuery);


});

         function test2(){
          document.getElementById("emplacement").style.display = "block";
         }
    </script>
       
        <div>

         <video id="log" autoplay loop muted>
        
         <source src="file:///Users/asmaid-belkhir/Downloads/c31ee86d00714601ac10a8ac81598ba6.webm" type="video/webm">
        
        </video>
        </div>

        <menu>
          <ul>
              <br>
            <li>
              <a href="./index.html">ACCUEIL</a>
            
            </li>
         
           <br>
        
            <li>
             <a href="./about.html">NOS REGALS</a>
          </li>
       
        <br>
           
            <li>GALERIE</li>
          
         <br> 
            <li>
             <a href="./contactus.html">CONTACT</a>
          </li>
        
          <br>
            <li>
             <a href="./connexion.html">CONNEXION</a>
          </li>
          <br>

         
          
          
            <li>

             <div class=form >
              <FORM>
          
                  <input id="emplacement" aria-label="search " class="syndicated-navigation__chrome__search__form__input syndicated-navigation__chrome__search__form__input--wdw" type="text" placeholder="search " maxlength="254" autocomplete="off" name="searchQuery" value="">
                  
                   <button  class="search" id="serch" name="searchBtn" onclick="test2();"> 
                   </button> 
            
           </FORM>
           
         </div>
         </li>

         </ul>

         </div>
        </menu>

      </header>

      <?php
$id = $_GET['id'];
include('DAO.php');
$dao = new DAO();
$data=$dao->infor($id);
foreach($data as $in) {
  echo '
  <FORM id="info">

      <br>
         <legend class="principal">Informations personnelles</legend>
         <br>
        <span id="np">
         Nom  : <INPUT TYPE="text"
     value="' . $in[0] . '"
                           NAME="identifiant" SIZE="40" id="pl"></INPUT>
         <br>
        Prénom: <INPUT TYPE="text"
    value="' . $in[1] . '"
                       NAME="password" SIZE="40" id="pl"></INPUT>
         <br>
        
     Date de naissance <INPUT TYPE="text"
     value="' . $in[2] . '"
                       NAME="password" SIZE="40" id="pl"></INPUT>
         <br>

    Numéro SS <INPUT TYPE="text"
     value="' . $in[3] . '" readonly
                       NAME="password" SIZE="40" id="pl"></INPUT>
         <br>
         </span>
     
       <br>
       <label id="np"for="manege">Manèges</label>
     <select  name="manege" size="1">
      <Option value="manege">--Veuillez choisir une option--</Option>
        <option value="big noise">big noise</option>
        <option value="splash">splash</option>
        <option value="Bay slides">Bay slides</option>
        <option value="indiana jones">indiana jones</option>
        <option value="Alices curious labyrinth">Alices curious labyrinth</option>
        <option value="la cabane des robinsons">la cabane des robinsons</option>
        <option value="Balade en bateau">Balade en bateau</option>
        <option value="afterburner">afterburner</option>

     </select>
     <br>
     <label id="np" for="maintenance">Manèges en maintenance</label>
<input type="radio" id="maintenance" name="maintenance" value="1">
<label id="np" for="maintenance">Oui</label>
<input type="radio" id="non-maintenance" name="maintenance" value="0">
<label id="np" for="non-maintenance">Non</label>
      </span>  
      <br>
       <input id="enreg" class="envoie" type="submit" value="enregistrer">
   </FORM>
  ';
  

}
?>




</body>
</html>