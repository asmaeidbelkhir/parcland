


Projet SAE4 partie programmation web :

nom prénom : Id-belkhir Asma   numero étudiant : 22016308  


Personnel du parc ParcLand :
ss= identifiant (numero de ss)  
mdp= mot de passe 

personnel (employe) :

ss: 444556673    mdp:  mdp126crypte
ss: 444556674    mdp:  mdp127crypte
ss: 444556675        mdp:  mdp128crypte
ss: 4445563680       mdp:  mdp134crypte
ss: 4445566650       mdp:  mdp136crypte
les chargés de manèges :

ss: 111223344   mdp : mdp123crypte
ss: 222334455   mdp : mdp456crypte
ss: 333445566   mdp : mdp789crypte
ss: 444556677   mdp : mdp101crypte
ss: 444556678    mdp122crypte
ss: 444556679    mdp123crypte
444556671    mdp124crypte
444556672    mdp125crypte

Directeur :
 
ss: 444556690 mdp: mdp135crypte






Les techniciens  :
4445566480  mdp139crypte
444556676  mdp129crypte
444556679  mdp130crypte
444556680  mdp131crypte


Le fichier myparam.inc.php je l'ai remplacé en faisant un autre nommé DAO.php et c'est ou j'ai mis la fonction de connexion et toute les fonctions de page de connexion/deconnexion, l'ajoute du personnel ... toute les fonctionnalités que j'ai fait dans mon projet 