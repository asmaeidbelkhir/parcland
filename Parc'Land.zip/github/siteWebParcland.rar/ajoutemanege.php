<!DOCTYPE html>
<HTML LANG="fr">
<head> 
<TITLE>
 pageconnex.html
 </TITLE>
 <STYLE type="text/css">
body {
  margin: 0;
  padding: 0;
  border: 0;
} 
.video-container {
  position: relative;
}

#vid {
  position: fixed;
  top: 0;
  left: 0;
  min-width: 100%;
  min-height: 100%;
  z-index: -1;
}

.video-container .content {
  position: relative;
  z-index: 1;
  padding: 20px;
  box-sizing: border-box;
  margin-top: 100px;
}



.hero {

  background-repeat: no-repeat;
  background-size: cover;
}

#log {
  position: fixed;
  top: 10px;
  left: 10px;
  width: 115px;
  height: 115px;
  z-index: 9999;
}

/*.hero::before {
  content: "";
  background: rgb(0 0 0 / 20%);
  width: 100vw;
  height: 100vh;
  position: absolute;
  z-index: 0;
} */

.hero header {

   z-index: 1;
  background-color: rgba(0,0,0,0.5);
  display: grid ;
  grid-template-columns: 20% 80%;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100px;
 
  max-width: 2800;
  width: 100%;
  margin: 0 auto;
  padding: 10px 16px;
  
}
.hero header menu {
  float: right;
  margin : 25px 20px ;
  padding: 0;
}
.hero header menu ul {
  list-style: none;
  padding: 0;
  display: flex;
  gap: 1em;
  color: white;
}
.hero header menu ul li {
}

.hero header menu ul li a {
  text-decoration: none;
  color: white;

}

.hero header menu .search {
      background: no-repeat url(https://cdn1.parksmedia.wdprapps.disney.com/media/layout/assets/icons/pep/search.svg);
    
    background-position: right top;
    height: 20px;
    width: 20px;
    padding: 4px 4px;
    border: 2px solid white;
    background-color: white;
    border-radius: 10%;

}
  #emplacement {  border: 4px solid white ;
}


#info{ 
 
  grid-template-columns: 20% 80%;
  
  font-size: 25pt;

        margin:100px 350px;
        color:black;
         
           border: 8px 8px 8px solid #676264 ;
           background-color: white;
           border-radius: 10%;
           box-shadow: 10px 10px 10px #676264;
           text-align: center;
           height: 70vh;
           }
      #np{   font-size: 15pt;
}      
 #enreg {    border: 2px solid black;
                         background-color: black;
                         border-radius: 10%;
                         text-align: center;
                         color: white;
 
           } 


 </STYLE>

</head>
<body>
<div class="video-container">
  <video id="vid" class="html5VideoPlayer no-media-autotrack" poster="https://cdn1.parksmedia.wdprapps.disney.com/resize/mwImage/2/1280/720/75/vision-dam/digital/parks-platform/parks-global-assets/disney-world/campaign/six-parks/walt-disney-world-six-parks-UK-16x9.jpg" autoplay="autoplay" loop="loop" muted="" src="https://cdn1.parksmedia.wdprapps.disney.com/vision-dam/digital/parks-platform/parks-global-assets/disney-world/campaign/six-parks/walt-disney-world-six-parks-UK-loop-video-1280x720.mp4"></video>

  <div class="content">

    <div class="hero" id="hero">
      <header>
       <script src="./script.js">
          const searchBtn = document.getElementById("search");
         
         searchBtn.addEventListener("click", function test(event) {
          alert("ok");
          //event.preventDefault(); // Empêche le formulaire de se soumettre
          document.getElementById("emplacement").style.display = "block";
       //const searchBtn = document.getElementById("emplacement");
       //searchBtn.style.display = "block" ;
    
       //const searchQuery = document.querySelector("input[name='searchQuery']").value;
        //alert("Vous avez cherché : " + searchQuery);


});

         function test2(){
          document.getElementById("emplacement").style.display = "block";
         }
    </script>
       
        <div>

         <video id="log" autoplay loop muted>
        
         <source src="file:///Users/asmaid-belkhir/Downloads/c31ee86d00714601ac10a8ac81598ba6.webm" type="video/webm">
        
        </video>
        </div>

        <menu>
          <ul>
              <br>
            <li>
              <a href="./index.html">ACCUEIL</a>
            
            </li>
         
           <br>
        
            <li>
             <a href="./about.html">NOS REGALS</a>
          </li>
       
        <br>
           
            <li>GALERIE</li>
          
         <br> 
            <li>
             <a href="./contactus.html">CONTACT</a>
          </li>
        
          <br>
            <li>
             <a href="./connexion.html">CONNEXION</a>
          </li>
          <br>

         
          
          
            <li>

             <div class=form >
              <FORM>
          
                  <input id="emplacement" aria-label="search " class="syndicated-navigation__chrome__search__form__input syndicated-navigation__chrome__search__form__input--wdw" type="text" placeholder="search " maxlength="254" autocomplete="off" name="searchQuery" value="">
                  
                   <button  class="search" id="serch" name="searchBtn" onclick="test2();"> 
                   </button> 
            
           </FORM>
           
         </div>
         </li>

         </ul>

         </div>
        </menu>

      </header>

<FORM action="controllers/addmanege.php" method='post' id="info">

      <br>
         <legend class="principal">Ajouter une manège</legend>
         <br>
        <span id="np">
         Id manège: <INPUT TYPE="text"
       NAME="Id_manege" SIZE="40" id="Id_manege"></INPUT>
         <br>
        Nom manège: <INPUT TYPE="text"
                       NAME="nom_manege" SIZE="40" id="nom_manege"></INPUT>
         <br>
        
     Description de manège <INPUT TYPE="text"
     
                       NAME="description" SIZE="40" id="description"></INPUT>
         <br>

    Taille minimale du client <INPUT TYPE="text"
                       NAME="taillmin" SIZE="40" id="taillmin"></INPUT>
         <br>
    Famille de manège <INPUT TYPE="text"
                       NAME="famille_manege" SIZE="40" id="famille_manege"></INPUT>
                       <br>
     Id zone <INPUT TYPE="text"
                   NAME="id_zone" SIZE="40" id="id_zone"></INPUT>
         <br>
         <br>
         </span>
     
       <br>
       

       <input id="enreg" class="envoie" type="submit" value="enregistrer">
   </FORM>


</body>
</html>