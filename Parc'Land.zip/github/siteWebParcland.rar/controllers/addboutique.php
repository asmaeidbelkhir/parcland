<?php
    $id_boutique=$_POST['id_boutique'];
	$nom_boutique=$_POST['nom_boutique'];
	$type_boutique=$_POST['type_boutique'];
    $emplacement=$_POST['emplacement']; 
    $CA=$_POST['CA'];
    $nb_client=$_POST['nb_client'];
    session_start();
	include('../DAO.php');
	$dao=new DAO();
	if($dao->Addboutique($id_boutique,$nom_boutique,$type_boutique,$emplacement,$CA,$nb_client)){
		header("location:../ajouteboutique.php");
	}else{
		header("location:../ajouteboutique.php?erreur=2");
		die();
	}   

?>