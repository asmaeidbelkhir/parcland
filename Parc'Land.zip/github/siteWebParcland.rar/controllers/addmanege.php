<?php
    $id=$_POST['Id_manege'];
	$nom=$_POST['nom_manege'];
	$description=$_POST['description'];
    $taillmin=$_POST['taillmin']; 
    $famille_manege=$_POST['famille_manege'];
    $id_zone=$_POST['id_zone'];
    session_start();
	include('../DAO.php');
	$dao=new DAO();
	if($dao->addmanege($id,$nom,$description,$taillmin,$famille_manege,$id_zone)){
		header("location:../ajoutemanege.php");
	}else{
		header("location:../ajoutemanege.php?erreur=2");
		die();
	}   

?>

