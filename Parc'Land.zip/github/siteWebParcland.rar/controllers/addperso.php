<?php
    $id=$_POST['id_personnel'];
	$nom=$_POST['nom'];
	$prenom=$_POST['prenom'];
    $date=$_POST['date_naissance']; 
    $SS=$_POST['ss'];
    $password=$_POST['mdp'];
    session_start();
	include('../DAO.php');
	$dao=new DAO();
	if($dao->Addperso($id,$nom,$prenom,$date,$SS,$password)){
		header("location:../ajoutepersonnel.php");
	}else{
		header("location:../ajoutepersonnel.php?erreur=2");
		die();
	}   

?>