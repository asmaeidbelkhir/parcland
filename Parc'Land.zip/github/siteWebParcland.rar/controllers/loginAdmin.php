<?php
	$ss = $_POST['identifiant'];
	$mdp = $_POST['password'];
	include('../DAO.php');
	$dao = new DAO();

	if($dao->authentificationUser($ss,$mdp)) {
		$prof = $dao->whichuser($ss);

		foreach($prof as $in) {
			$profession = $in[0];
		}

	
		session_start();	

		if ($profession == "directeur") {
			header("location: ../pagedirecteur.php?id=$ss");
		} else if($profession == "personnel") {
			header("location: ../pageperso.php?id=$ss");
		} else if($profession == "technicien") {
			header("location: ../pagetech.php?id=$ss");
		} else if($profession == "CM") {
			header("location: ../pageCM.php?id=$ss");
		}
	} else {
		header("location: ../conne.php?erreur=2");
		die();
	}
?>
