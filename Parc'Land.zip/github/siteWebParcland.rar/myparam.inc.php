<?php 
define("MYHOST","localhost"); 
define("MYUSER","parcland"); 
define("MYPASS","sae4"); 
define("MYBASE","parc"); 
?>