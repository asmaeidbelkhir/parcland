<?php
class DAO
{
	public function __construct()
	{
	}
	public function connexion()
	{
		$pdo = new PDO('mysql:host=127.0.0.1;dbname=parc', 'parcland', 'sae4');
		return $pdo;
	}



public function authentificationUser($email, $password)
	{
		$bdd = $this->connexion();
		$reponse = $bdd->prepare("SELECT * from Personnel where ss= ? and mdp = ?");
		$reponse->execute([$email, $password]);
		if ($ligne = $reponse->fetch()) return true;
		else return false;
	}
	public function whichuser($email){
		$bdd=$this->connexion();
		$reponse=$bdd->prepare("SELECT profession from Personnel where ss=? ");
		$reponse->execute([$email]);
		$lst = [];
		while ($ligne = $reponse->fetch()) {
			$lst[] = [$ligne[0]];
		}
		$reponse->closeCursor();
		return $lst;
	}

	public function infor($email){
		$bdd=$this->connexion();
		$reponse=$bdd->prepare("SELECT * from Personnel where ss=? ");
		$reponse->execute([$email]);
		$lst = [];
		while ($ligne = $reponse->fetch()) {
			$lst[] = [$ligne[1],$ligne[2],$ligne[3],$ligne[4]];
		}
		$reponse->closeCursor();
		return $lst;
	}
	public function Addperso($id, $nom, $prenom, $date,$ss, $mdp)
	{
		$bdd = $this->connexion();
		$reponse = $bdd->prepare("INSERT INTO personnel(id_personnel,nom,prenom,date_naissance,ss,mdp) values(?,?,?,?,?,?)");
		$reponse->execute([$id,$nom, $prenom, $date, $ss, $mdp]);
		if ($ligne = $reponse->fetch()) return true;
		else return false;
	}

	public function Addboutique($id_boutique,$nom_boutique,$type_boutique,$emplacement,$CA,$nb_client)
	{
	
		$bdd = $this->connexion();
		$reponse = $bdd->prepare("INSERT INTO boutique(id_boutique,nom_boutique,type_boutique,emplacement,CA,nb_client) values(?,?,?,?,?,?)");
		$reponse->execute([$id_boutique,$nom_boutique, $type_boutique, $emplacement, $CA, $nb_client]);
		if ($ligne = $reponse->fetch()) return true;
		else return false;
	}

	public function addmanege($id,$nom,$description,$taillmin,$famille_manege,$id_zone)
	{
		$bdd = $this->connexion();
		$reponse = $bdd->prepare("INSERT INTO manege(id_manege,nom_manege,description,taillemin,famille_manege,id_zone) values(?,?,?,?,?,?)");
		$reponse->execute([$id,$nom, $description, $taillmin, $famille_manege, $id_zone]);
		if ($ligne = $reponse->fetch()) return true;
		else return false;
	}


}
?>