-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le : dim. 02 avr. 2023 à 04:20
-- Version du serveur :  5.7.34
-- Version de PHP : 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `parc`
--

-- --------------------------------------------------------

--
-- Structure de la table `Atelier`
--

CREATE TABLE `Atelier` (
  `id_atelier` int(11) NOT NULL,
  `nom_atelier` varchar(50) DEFAULT NULL,
  `id_zone` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Atelier`
--

INSERT INTO `Atelier` (`id_atelier`, `nom_atelier`, `id_zone`) VALUES
(101, 'verti_at', 2201),
(102, 'aqua_at', 2202),
(103, 'adven_at', 2203),
(104, 'fanta_at', 2204);

-- --------------------------------------------------------

--
-- Structure de la table `Boutique`
--

CREATE TABLE `Boutique` (
  `id_boutique` int(11) NOT NULL,
  `nom_boutique` varchar(50) DEFAULT NULL,
  `type_boutique` varchar(50) DEFAULT NULL,
  `emplacement` varchar(50) DEFAULT NULL,
  `CA` decimal(15,2) DEFAULT NULL,
  `nb_client` int(11) DEFAULT NULL,
  `id_zone` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Boutique`
--

INSERT INTO `Boutique` (`id_boutique`, `nom_boutique`, `type_boutique`, `emplacement`, `CA`, `nb_client`, `id_zone`) VALUES
(6301, 'parcland food', 'restaurant', 'fantasyland', '30000.00', 900, 2204),
(6302, 'parcland coffe', 'cafe', 'fantasyland', '39000.00', 1200, 2204),
(6303, 'legends of parcland', 'souvenirs', 'adventureland', '15000.00', 550, 2203);

-- --------------------------------------------------------

--
-- Structure de la table `CM`
--

CREATE TABLE `CM` (
  `id_personnel` int(11) NOT NULL,
  `id_cm` int(11) NOT NULL,
  `date_dispo` date DEFAULT NULL,
  `famille` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `CM`
--

INSERT INTO `CM` (`id_personnel`, `id_cm`, `date_dispo`, `famille`) VALUES
(1, 1, '2023-06-30', 'Famille1'),
(2, 2, '2023-08-15', 'Famille2'),
(3, 3, '2023-07-20', 'Famille3'),
(4, 4, '2023-09-10', 'Famille1'),
(5, 15, '2023-07-10', 'Famille1'),
(6, 16, '2023-07-10', 'Famille2'),
(7, 17, '2023-06-10', 'Famille3'),
(8, 18, '2023-10-10', 'Famille1');

-- --------------------------------------------------------

--
-- Structure de la table `Directeur`
--

CREATE TABLE `Directeur` (
  `id_personnel` int(11) NOT NULL,
  `id_directeur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Directeur`
--

INSERT INTO `Directeur` (`id_personnel`, `id_directeur`) VALUES
(18, 22016308);

-- --------------------------------------------------------

--
-- Structure de la table `Employe`
--

CREATE TABLE `Employe` (
  `id_personnel` int(11) NOT NULL,
  `id_employe` int(11) NOT NULL,
  `nom_metier` varchar(50) DEFAULT NULL,
  `responsable_boutique` varchar(50) DEFAULT NULL,
  `id_boutique` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Employe`
--

INSERT INTO `Employe` (`id_personnel`, `id_employe`, `nom_metier`, `responsable_boutique`, `id_boutique`) VALUES
(9, 64, 'vendeur', 'oui', 6301),
(10, 65, 'serveur', 'non', 6301),
(11, 68, 'vendeur', 'oui', 6303),
(15, 66, 'vendeur', 'oui', 6302),
(17, 67, 'serveur', 'non', 6302);

-- --------------------------------------------------------

--
-- Structure de la table `Manege`
--

CREATE TABLE `Manege` (
  `id_manege` int(11) NOT NULL,
  `nom_manege` varchar(50) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `taillemin` decimal(15,2) DEFAULT NULL,
  `maintenance` varchar(100) DEFAULT NULL,
  `famille_manege` varchar(50) DEFAULT NULL,
  `id_zone` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Manege`
--

INSERT INTO `Manege` (`id_manege`, `nom_manege`, `description`, `taillemin`, `maintenance`, `famille_manege`, `id_zone`) VALUES
(10, 'big noise', 'divertissement pour les plus petits', '0.00', '0', 'chenille', 2204),
(11, 'splash', 'aventure en famille', '0.00', '1', 'chevaux', 2203),
(12, 'Bay Slides', 'Les toboggans à deux corps offrent des sensations réduites pour les\r\ntout-petits', '152.00', '0', 'aquatic', 2202),
(13, 'indiana jones et le temple du péril', 'grand frissons fastpass', '140.00', '1', 'vertigo', 2201),
(14, 'Alices curious labyrinth', 'grand frissons fastpass', '0.00', '1', 'chenille', 2204),
(15, 'la cabane des robinsons', 'aventure en famille', '0.00', '1', 'chevaux', 2203),
(16, 'Balade en bateau', 'divertissement pour les plus petits', '0.00', '0', 'aquatic', 2202),
(17, 'afterburner', 'grand frissons fastpass', '140.00', '1', 'vertigo', 2201);

-- --------------------------------------------------------

--
-- Structure de la table `Nb_client`
--

CREATE TABLE `Nb_client` (
  `id_manege` int(11) NOT NULL,
  `id_nbclient` int(11) NOT NULL,
  `nombre_client_demijournee` int(11) DEFAULT NULL,
  `date_enregistrement` date DEFAULT NULL,
  `demi_journee` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Nb_client`
--

INSERT INTO `Nb_client` (`id_manege`, `id_nbclient`, `nombre_client_demijournee`, `date_enregistrement`, `demi_journee`) VALUES
(10, 5000, 300, '2023-06-01', 1),
(11, 5100, 460, '2023-06-02', 2),
(12, 5200, 350, '2023-06-03', 3),
(13, 5300, 560, '2023-06-04', 4),
(14, 5400, 880, '2023-06-05', 5),
(15, 5500, 876, '2023-06-06', 6),
(16, 5600, 900, '2023-06-07', 7),
(17, 5700, 897, '2023-06-08', 8);

-- --------------------------------------------------------

--
-- Structure de la table `Objet`
--

CREATE TABLE `Objet` (
  `id_objet` int(11) NOT NULL,
  `nom_objet` varchar(50) DEFAULT NULL,
  `en_stock` varchar(50) DEFAULT NULL,
  `prix_objet` decimal(15,2) DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Objet`
--

INSERT INTO `Objet` (`id_objet`, `nom_objet`, `en_stock`, `prix_objet`, `Type`) VALUES
(20, 'peluche mickeymouse', '0', '24.00', 'peluche'),
(21, 'parcland Tshirt', '1', '10.00', 'souvenirs'),
(22, 'parcland magnet', '1', '5.00', 'souvenirs'),
(23, 'parcland stylo', '0', '3.00', 'papeterie'),
(24, 'peluche simba', '1', '26.00', 'peluche'),
(25, 'costume princesse anna', '1', '35.00', 'deguisements'),
(26, 'costume reine des neiges', '1', '40.00', 'deguisements');

-- --------------------------------------------------------

--
-- Structure de la table `Personnel`
--

CREATE TABLE `Personnel` (
  `id_personnel` int(11) NOT NULL,
  `nom` varchar(50) DEFAULT NULL,
  `prenom` varchar(50) DEFAULT NULL,
  `date_naissance` date DEFAULT NULL,
  `ss` varchar(50) DEFAULT NULL,
  `mdp` varchar(32) DEFAULT NULL,
  `profession` enum('CM','technicien','personnel','directeur') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Personnel`
--

INSERT INTO `Personnel` (`id_personnel`, `nom`, `prenom`, `date_naissance`, `ss`, `mdp`, `profession`) VALUES
(1, 'Dupont', 'Jean', '1985-05-20', '111223344', 'mdp123crypte', 'CM'),
(2, 'Martin', 'Marie', '1990-08-15', '222334455', 'mdp456crypte', 'CM'),
(3, 'Lefevre', 'Pierre', '1975-12-02', '333445566', 'mdp789crypte', 'CM'),
(4, 'Dubois', 'Sophie', '1988-03-19', '444556677', 'mdp101crypte', 'CM'),
(5, 'Dupuy', 'Thomas', '1987-06-20', '444556678', 'mdp122crypte', 'CM'),
(6, 'Vasseur', 'Leroy', '1998-09-15', '444556679', 'mdp123crypte', 'CM'),
(7, 'peres', 'michel', '1987-01-06', '444556671', 'mdp124crypte', 'CM'),
(8, 'Moulin', 'Laura', '1997-04-18', '444556672', 'mdp125crypte', 'CM'),
(9, 'Roux', 'Louis', '1988-05-19', '444556673', 'mdp126crypte', 'personnel'),
(10, 'Bonnet', 'Adam', '1982-03-10', '444556674', 'mdp127crypte', 'personnel'),
(11, 'Boucher', 'David', '1992-04-02', '444556675', 'mdp128crypte', 'personnel'),
(12, 'fournier', 'Klein', '1979-05-02', '444556676', 'mdp129crypte', 'technicien'),
(13, 'Menard', 'Andret', '1996-12-10', '444556679', 'mdp130crypte', 'technicien'),
(14, 'Faurd', 'Charle', '1986-11-10', '444556680', 'mdp131crypte', 'technicien'),
(15, 'Robin', 'Julien', '1986-12-05', '4445563680', 'mdp134crypte', 'personnel'),
(16, 'joly', 'remi', '1998-01-11', '4445566480', 'mdp139crypte', 'technicien'),
(17, 'Riviere', 'Hamont', '1996-11-09', '4445566650', 'mdp136crypte', 'personnel'),
(18, 'Roy', 'Jacob', '1980-01-04', '444556690', 'mdp135crypte', 'directeur');

-- --------------------------------------------------------

--
-- Structure de la table `Piece`
--

CREATE TABLE `Piece` (
  `id_piece` int(11) NOT NULL,
  `nom_piece` varchar(50) DEFAULT NULL,
  `quantite_piece` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Piece`
--

INSERT INTO `Piece` (`id_piece`, `nom_piece`, `quantite_piece`) VALUES
(201, 'plaques tournantes', 33),
(202, 'Moteurs', 10),
(203, 'Boîtes de vitesses', 6),
(204, 'Volant ', 60),
(205, 'controleur de carte ', 20),
(206, 'boulon noir ', 50);

-- --------------------------------------------------------

--
-- Structure de la table `prend_encharge`
--

CREATE TABLE `prend_encharge` (
  `id_manege` int(11) NOT NULL,
  `id_personnel` int(11) NOT NULL,
  `id_cm` int(11) NOT NULL,
  `date_encharge` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `prend_encharge`
--

INSERT INTO `prend_encharge` (`id_manege`, `id_personnel`, `id_cm`, `date_encharge`) VALUES
(10, 1, 1, '2023-06-30');

-- --------------------------------------------------------

--
-- Structure de la table `Remplace`
--

CREATE TABLE `Remplace` (
  `id_personnel_est_remplace` int(11) NOT NULL,
  `id_cm_est_remplace` int(11) NOT NULL,
  `id_personnel_remplace` int(11) NOT NULL,
  `id_cm_remplace` int(11) NOT NULL,
  `date_remplacement` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Remplace`
--

INSERT INTO `Remplace` (`id_personnel_est_remplace`, `id_cm_est_remplace`, `id_personnel_remplace`, `id_cm_remplace`, `date_remplacement`) VALUES
(1, 1, 4, 4, '2023-11-11'),
(2, 2, 1, 1, '2023-06-30');

-- --------------------------------------------------------

--
-- Structure de la table `Reparation`
--

CREATE TABLE `Reparation` (
  `id_manege` int(11) NOT NULL,
  `id_personnel` int(11) NOT NULL,
  `id_technicien` int(11) NOT NULL,
  `id_piece` int(11) NOT NULL,
  `date_reparation` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Reparation`
--

INSERT INTO `Reparation` (`id_manege`, `id_personnel`, `id_technicien`, `id_piece`, `date_reparation`) VALUES
(13, 12, 81, 203, '2022-03-12'),
(16, 13, 82, 204, '2023-09-25');

-- --------------------------------------------------------

--
-- Structure de la table `Stock`
--

CREATE TABLE `Stock` (
  `id_atelier` int(11) NOT NULL,
  `id_piece` int(11) NOT NULL,
  `quantite` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Stock`
--

INSERT INTO `Stock` (`id_atelier`, `id_piece`, `quantite`) VALUES
(101, 201, 33),
(102, 204, 60),
(103, 203, 6),
(104, 206, 50);

-- --------------------------------------------------------

--
-- Structure de la table `Technicien`
--

CREATE TABLE `Technicien` (
  `id_personnel` int(11) NOT NULL,
  `id_technicien` int(11) NOT NULL,
  `responsable_atelier` varchar(50) DEFAULT NULL,
  `id_atelier` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Technicien`
--

INSERT INTO `Technicien` (`id_personnel`, `id_technicien`, `responsable_atelier`, `id_atelier`) VALUES
(12, 81, '1', 102),
(13, 82, '1', 103),
(14, 80, '1', 101),
(16, 83, '1', 104);

-- --------------------------------------------------------

--
-- Structure de la table `Vend`
--

CREATE TABLE `Vend` (
  `id_boutique` int(11) NOT NULL,
  `id_objet` int(11) NOT NULL,
  `date_vente` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Vend`
--

INSERT INTO `Vend` (`id_boutique`, `id_objet`, `date_vente`) VALUES
(6303, 20, '2023-06-09'),
(6303, 21, '2023-06-01'),
(6303, 22, '2023-06-02'),
(6303, 23, '2023-06-01');

-- --------------------------------------------------------

--
-- Structure de la table `Zone`
--

CREATE TABLE `Zone` (
  `id_zone` int(11) NOT NULL,
  `nom_zone` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Zone`
--

INSERT INTO `Zone` (`id_zone`, `nom_zone`) VALUES
(2201, 'vertigoland'),
(2202, 'aquaticland'),
(2203, 'adventureland'),
(2204, 'fantasyland');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `Atelier`
--
ALTER TABLE `Atelier`
  ADD PRIMARY KEY (`id_atelier`),
  ADD KEY `id_zone` (`id_zone`);

--
-- Index pour la table `Boutique`
--
ALTER TABLE `Boutique`
  ADD PRIMARY KEY (`id_boutique`),
  ADD KEY `id_zone` (`id_zone`);

--
-- Index pour la table `CM`
--
ALTER TABLE `CM`
  ADD PRIMARY KEY (`id_personnel`,`id_cm`);

--
-- Index pour la table `Directeur`
--
ALTER TABLE `Directeur`
  ADD PRIMARY KEY (`id_personnel`,`id_directeur`);

--
-- Index pour la table `Employe`
--
ALTER TABLE `Employe`
  ADD PRIMARY KEY (`id_personnel`,`id_employe`),
  ADD KEY `id_boutique` (`id_boutique`);

--
-- Index pour la table `Manege`
--
ALTER TABLE `Manege`
  ADD PRIMARY KEY (`id_manege`),
  ADD KEY `id_zone` (`id_zone`);

--
-- Index pour la table `Nb_client`
--
ALTER TABLE `Nb_client`
  ADD PRIMARY KEY (`id_manege`,`id_nbclient`);

--
-- Index pour la table `Objet`
--
ALTER TABLE `Objet`
  ADD PRIMARY KEY (`id_objet`);

--
-- Index pour la table `Personnel`
--
ALTER TABLE `Personnel`
  ADD PRIMARY KEY (`id_personnel`);

--
-- Index pour la table `Piece`
--
ALTER TABLE `Piece`
  ADD PRIMARY KEY (`id_piece`);

--
-- Index pour la table `prend_encharge`
--
ALTER TABLE `prend_encharge`
  ADD PRIMARY KEY (`id_manege`,`id_personnel`,`id_cm`),
  ADD KEY `id_personnel` (`id_personnel`,`id_cm`);

--
-- Index pour la table `Remplace`
--
ALTER TABLE `Remplace`
  ADD PRIMARY KEY (`id_personnel_est_remplace`,`id_cm_est_remplace`,`id_personnel_remplace`,`id_cm_remplace`),
  ADD KEY `id_personnel_remplace` (`id_personnel_remplace`,`id_cm_remplace`);

--
-- Index pour la table `Reparation`
--
ALTER TABLE `Reparation`
  ADD PRIMARY KEY (`id_manege`,`id_personnel`,`id_technicien`,`id_piece`),
  ADD KEY `id_personnel` (`id_personnel`,`id_technicien`),
  ADD KEY `id_piece` (`id_piece`);

--
-- Index pour la table `Stock`
--
ALTER TABLE `Stock`
  ADD PRIMARY KEY (`id_atelier`,`id_piece`),
  ADD KEY `id_piece` (`id_piece`);

--
-- Index pour la table `Technicien`
--
ALTER TABLE `Technicien`
  ADD PRIMARY KEY (`id_personnel`,`id_technicien`),
  ADD KEY `id_atelier` (`id_atelier`);

--
-- Index pour la table `Vend`
--
ALTER TABLE `Vend`
  ADD PRIMARY KEY (`id_boutique`,`id_objet`),
  ADD KEY `id_objet` (`id_objet`);

--
-- Index pour la table `Zone`
--
ALTER TABLE `Zone`
  ADD PRIMARY KEY (`id_zone`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `Atelier`
--
ALTER TABLE `Atelier`
  ADD CONSTRAINT `atelier_ibfk_1` FOREIGN KEY (`id_zone`) REFERENCES `Zone` (`id_zone`);

--
-- Contraintes pour la table `Boutique`
--
ALTER TABLE `Boutique`
  ADD CONSTRAINT `boutique_ibfk_1` FOREIGN KEY (`id_zone`) REFERENCES `Zone` (`id_zone`);

--
-- Contraintes pour la table `CM`
--
ALTER TABLE `CM`
  ADD CONSTRAINT `cm_ibfk_1` FOREIGN KEY (`id_personnel`) REFERENCES `Personnel` (`id_personnel`);

--
-- Contraintes pour la table `Directeur`
--
ALTER TABLE `Directeur`
  ADD CONSTRAINT `directeur_ibfk_1` FOREIGN KEY (`id_personnel`) REFERENCES `Personnel` (`id_personnel`);

--
-- Contraintes pour la table `Employe`
--
ALTER TABLE `Employe`
  ADD CONSTRAINT `employe_ibfk_1` FOREIGN KEY (`id_personnel`) REFERENCES `Personnel` (`id_personnel`),
  ADD CONSTRAINT `employe_ibfk_2` FOREIGN KEY (`id_boutique`) REFERENCES `Boutique` (`id_boutique`);

--
-- Contraintes pour la table `Manege`
--
ALTER TABLE `Manege`
  ADD CONSTRAINT `manege_ibfk_1` FOREIGN KEY (`id_zone`) REFERENCES `Zone` (`id_zone`);

--
-- Contraintes pour la table `Nb_client`
--
ALTER TABLE `Nb_client`
  ADD CONSTRAINT `nb_client_ibfk_1` FOREIGN KEY (`id_manege`) REFERENCES `Manege` (`id_manege`);

--
-- Contraintes pour la table `prend_encharge`
--
ALTER TABLE `prend_encharge`
  ADD CONSTRAINT `prend_encharge_ibfk_1` FOREIGN KEY (`id_manege`) REFERENCES `Manege` (`id_manege`),
  ADD CONSTRAINT `prend_encharge_ibfk_2` FOREIGN KEY (`id_personnel`,`id_cm`) REFERENCES `CM` (`id_personnel`, `id_cm`);

--
-- Contraintes pour la table `Remplace`
--
ALTER TABLE `Remplace`
  ADD CONSTRAINT `remplace_ibfk_1` FOREIGN KEY (`id_personnel_est_remplace`,`id_cm_est_remplace`) REFERENCES `CM` (`id_personnel`, `id_cm`),
  ADD CONSTRAINT `remplace_ibfk_2` FOREIGN KEY (`id_personnel_remplace`,`id_cm_remplace`) REFERENCES `CM` (`id_personnel`, `id_cm`);

--
-- Contraintes pour la table `Reparation`
--
ALTER TABLE `Reparation`
  ADD CONSTRAINT `reparation_ibfk_1` FOREIGN KEY (`id_manege`) REFERENCES `Manege` (`id_manege`),
  ADD CONSTRAINT `reparation_ibfk_2` FOREIGN KEY (`id_personnel`,`id_technicien`) REFERENCES `Technicien` (`id_personnel`, `id_technicien`),
  ADD CONSTRAINT `reparation_ibfk_3` FOREIGN KEY (`id_piece`) REFERENCES `Piece` (`id_piece`);

--
-- Contraintes pour la table `Stock`
--
ALTER TABLE `Stock`
  ADD CONSTRAINT `stock_ibfk_1` FOREIGN KEY (`id_atelier`) REFERENCES `Atelier` (`id_atelier`),
  ADD CONSTRAINT `stock_ibfk_2` FOREIGN KEY (`id_piece`) REFERENCES `Piece` (`id_piece`);

--
-- Contraintes pour la table `Technicien`
--
ALTER TABLE `Technicien`
  ADD CONSTRAINT `technicien_ibfk_1` FOREIGN KEY (`id_personnel`) REFERENCES `Personnel` (`id_personnel`),
  ADD CONSTRAINT `technicien_ibfk_2` FOREIGN KEY (`id_atelier`) REFERENCES `Atelier` (`id_atelier`);

--
-- Contraintes pour la table `Vend`
--
ALTER TABLE `Vend`
  ADD CONSTRAINT `vend_ibfk_1` FOREIGN KEY (`id_boutique`) REFERENCES `Boutique` (`id_boutique`),
  ADD CONSTRAINT `vend_ibfk_2` FOREIGN KEY (`id_objet`) REFERENCES `Objet` (`id_objet`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
