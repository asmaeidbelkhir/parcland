
//creation des tables 

CREATE TABLE Personnel(
   id_personnel INT,
   nom VARCHAR(50),
   prenom VARCHAR(50),
   date_naissance DATE,
   ss VARCHAR(50),
   mdp VARCHAR(32),
   profession enum('CM','technicien','personnel','directeur'),
   PRIMARY KEY(id_personnel)
);

CREATE TABLE CM(
   id_personnel INT,
   id_cm INT,
   date_dispo DATE,
   famille VARCHAR(50),
   PRIMARY KEY(id_personnel, id_cm),
   FOREIGN KEY(id_personnel) REFERENCES Personnel(id_personnel)
);

CREATE TABLE Directeur(
   id_personnel INT,
   id_directeur INT,
   PRIMARY KEY(id_personnel, id_directeur),
   FOREIGN KEY(id_personnel) REFERENCES Personnel(id_personnel)
);

CREATE TABLE Objet(
   id_objet INT,
   nom_objet VARCHAR(50),
   en_stock LOGICAL,
   prix_objet DECIMAL(15,2),
   Type VARCHAR(50),
   PRIMARY KEY(id_objet)
);

CREATE TABLE Zone(
   id_zone INT,
   nom_zone VARCHAR(50),
   PRIMARY KEY(id_zone)
);

CREATE TABLE Atelier(
   id_atelier INT,
   nom_atelier VARCHAR(50),
   id_zone INT NOT NULL,
   PRIMARY KEY(id_atelier),
   FOREIGN KEY(id_zone) REFERENCES Zone(id_zone)
);

CREATE TABLE Piece(
   id_piece INT,
   nom_piece VARCHAR(50),
   quantite_piece INT,
   PRIMARY KEY(id_piece)
);

CREATE TABLE Manege(
   id_manege INT,
   nom_manege VARCHAR(50),
   description VARCHAR(100),
   taillemin DECIMAL(15,2),
   maintenance LOGICAL,
   famille_manege VARCHAR(50),
   id_zone INT NOT NULL,
   PRIMARY KEY(id_manege),
   FOREIGN KEY(id_zone) REFERENCES Zone(id_zone)
);

CREATE TABLE Technicien(
   id_personnel INT,
   id_technicien INT,
   responsable_atelier LOGICAL,
   id_atelier INT NOT NULL,
   PRIMARY KEY(id_personnel, id_technicien),
   FOREIGN KEY(id_personnel) REFERENCES Personnel(id_personnel),
   FOREIGN KEY(id_atelier) REFERENCES Atelier(id_atelier)
);

CREATE TABLE Directeur (
  'id_personnel' int(11), 
  'id_directeur' int(11),
  PRIMARY KEY(id_personnel,id_directeur),
  FOREIGN KEY(id_personnel) REFERENCES personnel(id_personnel)
)

CREATE TABLE Boutique(
   id_boutique INT,
   nom_boutique VARCHAR(50),
   type_boutique VARCHAR(50),
   emplacement VARCHAR(50),
   CA DECIMAL(15,2),
   nb_client INT,
   id_zone INT NOT NULL,
   PRIMARY KEY(id_boutique),
   FOREIGN KEY(id_zone) REFERENCES Zone(id_zone)
);

CREATE TABLE Nb_client(
   id_manege INT,
   id_nbclient INT,
   nombre_client_demijournee INT,
   date_enregistrement DATE,
   demi_journee INT,
   PRIMARY KEY(id_manege, id_nbclient),
   FOREIGN KEY(id_manege) REFERENCES Manege(id_manege)
);

CREATE TABLE Employe(
   id_personnel INT,
   id_employe INT,
   nom_metier VARCHAR(50),
   responsable_boutique LOGICAL,
   id_boutique INT NOT NULL,
   PRIMARY KEY(id_personnel, id_employe),
   FOREIGN KEY(id_personnel) REFERENCES Personnel(id_personnel),
   FOREIGN KEY(id_boutique) REFERENCES Boutique(id_boutique)
);

CREATE TABLE Vend(
   id_boutique INT,
   id_objet INT,
   date_vente DATE,
   PRIMARY KEY(id_boutique, id_objet),
   FOREIGN KEY(id_boutique) REFERENCES Boutique(id_boutique),
   FOREIGN KEY(id_objet) REFERENCES Objet(id_objet)
);

CREATE TABLE Stock(
   id_atelier INT,
   id_piece INT,
   quantite INT,
   PRIMARY KEY(id_atelier, id_piece),
   FOREIGN KEY(id_atelier) REFERENCES Atelier(id_atelier),
   FOREIGN KEY(id_piece) REFERENCES Piece(id_piece)
);

CREATE TABLE Reparation(
   id_manege INT,
   id_personnel INT,
   id_technicien INT,
   id_piece INT,
   date_reparation DATE,
   PRIMARY KEY(id_manege, id_personnel, id_technicien, id_piece),
   FOREIGN KEY(id_manege) REFERENCES Manege(id_manege),
   FOREIGN KEY(id_personnel, id_technicien) REFERENCES Technicien(id_personnel, id_technicien),
   FOREIGN KEY(id_piece) REFERENCES Piece(id_piece)
);

CREATE TABLE Remplace(
   id_personnel_est_remplace INT,
   id_cm_est_remplace INT,
   id_personnel_remplace INT,
   id_cm_remplace INT,
   date_remplacement DATE,
   PRIMARY KEY(id_personnel_est_remplace, id_cm_est_remplace, id_personnel_remplace, id_cm_remplace),
   FOREIGN KEY(id_personnel_est_remplace, id_cm_est_remplace) REFERENCES CM(id_personnel, id_cm),
   FOREIGN KEY(id_personnel_remplace, id_cm_remplace) REFERENCES CM(id_personnel, id_cm)
);

CREATE TABLE prend_encharge(
   id_manege INT,
   id_personnel INT,
   id_cm INT,
   date_encharge DATE,
   PRIMARY KEY(id_manege, id_personnel, id_cm),
   FOREIGN KEY(id_manege) REFERENCES Manege(id_manege),
   FOREIGN KEY(id_personnel, id_cm) REFERENCES CM(id_personnel, id_cm)
);

//les instructions sql de suppression des tables Oracle & Mysql 

//ORACLE 
DROP TABLE Remplace;
DROP TABLE prend_encharge;
DROP TABLE Reparation;
DROP TABLE Stock;
DROP TABLE Vend;
DROP TABLE Employe;
DROP TABLE Nb_client;
DROP TABLE Boutique;
DROP TABLE Technicien;
DROP TABLE Manege;
DROP TABLE Piece;
DROP TABLE Atelier;
DROP TABLE Zone;
DROP TABLE Directeur;
DROP TABLE CM;
DROP TABLE Personnel;

//mySQL  

DROP TABLE IF EXISTS Remplace;
DROP TABLE IF EXISTS prend_encharge;
DROP TABLE IF EXISTS Reparation;
DROP TABLE IF EXISTS Stock;
DROP TABLE IF EXISTS Vend;
DROP TABLE IF EXISTS Employe;
DROP TABLE IF EXISTS Nb_client;
DROP TABLE IF EXISTS Boutique;
DROP TABLE IF EXISTS Technicien;
DROP TABLE IF EXISTS Manege;
DROP TABLE IF EXISTS Piece;
DROP TABLE IF EXISTS Atelier;
DROP TABLE IF EXISTS Zone;
DROP TABLE IF EXISTS Directeur;
DROP TABLE IF EXISTS CM;
DROP TABLE IF EXISTS Personnel;

/*Rapport comprenant les requêtes compatible Oracle sous formes sql et algébriques
Liste des personnels avec leurs coordonnées:
Requête SQL:*/

SELECT P.id_personnel, P.nom, P.prenom, P.adresse, P.telephone
FROM Personnel P;

//Requête algébrique:

Π id_personnel, nom, prenom, adresse, telephone (Personnel)

Liste des chargés de manège avec le nom et le prénom du personnel:
Requête SQL:

SELECT CM.id_cm, P.nom, P.prenom
FROM CM, Personnel P
WHERE CM.id_personnel = P.id_personnel;

//Requête algébrique:

Π id_cm, nom, prenom (CM ⨝ Personnel)

/*Liste des personnels qui ont été remplacés lors d'un manège:*/
/*Requête SQL:*/
SELECT DISTINCT P1.id_personnel, P1.nom, P1.prenom
FROM Remplace R, Personnel P1
WHERE R.id_personnel_est_remplace = P1.id_personnel;
/*Requête algébrique:*/

Π id_personnel, nom, prenom (σ id_personnel_est_remplace=id_personnel (Remplace ⨝ Personnel))

/*Liste des remplacements avec les noms et prénoms des personnels remplacés et remplaçants:
Requête SQL: */

SELECT R.date_remplacement, P1.nom AS nom_remplace, P1.prenom AS prenom_remplace, P2.nom AS nom_remplacant, P2.prenom AS prenom_remplacant
FROM Remplace R, Personnel P1, Personnel P2
WHERE R.id_personnel_est_remplace = P1.id_personnel
AND R.id_personnel_remplace = P2.id_personnel;

/*Requête algébrique: */

Π date_remplacement, nom_remplace, prenom_remplace, nom_remplacant, prenom_remplacant ((Remplace ⨝ ρ id_personnel/id_personnel_est_remplace, nom/nom_remplace, prenom/prenom_remplace (Personnel)) ⨝ ρ id_personnel/id_personnel_remplace, nom/nom_remplacant, prenom/prenom_remplacant (Personnel))

/*les instructions sql de remplissage des tables Oracle & Mysql ;

Oracle: */

INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (1, 'Dupont', 'Jean', TO_DATE('1985-05-20', 'YYYY-MM-DD'), '111223344', 'mdp123crypte','CM');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (2, 'Martin', 'Marie', TO_DATE('1990-08-15', 'YYYY-MM-DD'), '222334455', 'mdp456crypte','CM');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (3, 'Lefevre', 'Pierre', TO_DATE('1975-12-02', 'YYYY-MM-DD'), '333445566', 'mdp789crypte','CM');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (4, 'Dubois', 'Sophie', TO_DATE('1988-03-19', 'YYYY-MM-DD'), '444556677', 'mdp101crypte','CM');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (5, 'Dupuy', 'Thomas', TO_DATE('1987-06-20', 'YYYY-MM-DD'), '444556678', 'mdp122crypte','CM');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (6, 'Vasseur', 'Leroy', TO_DATE('1998-09-15', 'YYYY-MM-DD'), '444556679', 'mdp123crypte','CM');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (7, 'peres', 'michel', TO_DATE('1987-01-06', 'YYYY-MM-DD'), '444556671', 'mdp124crypte','CM');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (8, 'Moulin', 'Laura', TO_DATE('1997-04-18', 'YYYY-MM-DD'), '444556672', 'mdp125crypte','CM');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (9, 'Roux', 'Louis', TO_DATE('1988-05-19', 'YYYY-MM-DD'), '444556673', 'mdp126crypte','personnel');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (10, 'Bonnet', 'Adam',TO_DATE('1982-03-10', 'YYYY-MM-DD') , '444556674', 'mdp127crypte','personnel');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (11, 'Boucher', 'David', TO_DATE('1992-04-02', 'YYYY-MM-DD'), '444556675', 'mdp128crypte','personnel');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (12, 'fournier', 'Klein', TO_DATE('1979-05-02', 'YYYY-MM-DD'), '444556676', 'mdp129crypte', 'technicien');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (13, 'Menard', 'Andret', TO_DATE('1996-12-10', 'YYYY-MM-DD'), '444556679', 'mdp130crypte','technicien');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (14, 'Faurd', 'Charle', TO_DATE('1986-11-10', 'YYYY-MM-DD'), '444556680', 'mdp131crypte','technicien');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (15, 'Robin', 'Julien',  TO_DATE('1986-12-05', 'YYYY-MM-DD'), '4445563680', 'mdp134crypte', 'personnel');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (16, 'joly', 'remi',  TO_DATE('1998-01-11', 'YYYY-MM-DD'), '4445566480', 'mdp139crypte', 'technicien');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (17, 'Riviere', 'Hamont',  TO_DATE('1996-11-09', 'YYYY-MM-DD'), '4445566650', 'mdp136crypte','personnel');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp, profession) VALUES (18, 'Roy', 'Jacob',  TO_DATE('1980-01-04', 'YYYY-MM-DD'), '444556690', 'mdp135crypte', 'directeur');





//MySQL:
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (1, 'Dupont', 'Jean', '1985-05-20', '111223344', 'mdp123crypte','CM');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (2, 'Martin', 'Marie', '1990-08-15', '222334455', 'mdp456crypte','CM');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (3, 'Lefevre', 'Pierre', '1975-12-02', '333445566', 'mdp789crypte','CM');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (4, 'Dubois', 'Sophie', '1988-03-19', '444556677', 'mdp101crypte','CM');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (5, 'Dupuy', 'Thomas', '1987-06-20', '444556678', 'mdp122crypte','CM');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (6, 'Vasseur', 'Leroy', '1998-09-15', '444556679', 'mdp123crypte','CM');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (7, 'peres', 'michel', '1987-01-06', '444556671', 'mdp124crypte','CM');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (8, 'Moulin', 'Laura', '1997-04-18', '444556672', 'mdp125crypte','CM');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (9, 'Roux', 'Louis', '1988-05-19', '444556673', 'mdp126crypte','personnel');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (10, 'Bonnet', 'Adam', '1982-03-10', '444556674', 'mdp127crypte','personnel');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (11, 'Boucher', 'David', '1992-04-02', '444556675', 'mdp128crypte','personnel');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (12, 'fournier', 'Klein', '1979-05-02', '444556676', 'mdp129crypte','technicien');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (13, 'Menard', 'Andret', '1996-12-10', '444556679', 'mdp130crypte','technicien');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (14, 'Faurd', 'Charle', '1986-11-10', '444556680', 'mdp131crypte','technicien');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (15, 'Robin', 'Julien', '1986-12-05', '4445563680', 'mdp134crypte','personnel');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (16, 'joly', 'remi', '1998-01-11', '4445566480', 'mdp139crypte','technicien');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (17, 'Riviere', 'Hamont', '1996-11-09', '4445566650', 'mdp136crypte','personnel');
INSERT INTO Personnel (id_personnel, nom, prenom, date_naissance, ss, mdp) VALUES (18, 'Roy', 'Jacob', '1980-01-04', '444556690', 'mdp135crypte', 'directeur');







/*Remplir la table CM:
Oracle:*/
INSERT INTO CM (id_cm, id_personnel, date_dispo, famille) VALUES (1, 1, TO_DATE('2023-06-30', 'YYYY-MM-DD'), 'Famille1');
INSERT INTO CM (id_cm, id_personnel, date_dispo, famille) VALUES (2, 2, TO_DATE('2023-08-15', 'YYYY-MM-DD'), 'Famille2');
INSERT INTO CM (id_cm, id_personnel, date_dispo, famille) VALUES (3, 3, TO_DATE('2023-07-20', 'YYYY-MM-DD'), 'Famille3');
INSERT INTO CM (id_cm, id_personnel, date_dispo, famille) VALUES (4, 4, TO_DATE('2023-09-10', 'YYYY-MM-DD'), 'Famille1');
INSERT INTO CM (id_cm, id_personnel, date_dispo, famille) VALUES (5, 15, TO_DATE('2023-07-10', 'YYYY-MM-DD'), 'Famille1');
INSERT INTO CM (id_cm, id_personnel, date_dispo, famille) VALUES (6, 16, TO_DATE('2023-07-10', 'YYYY-MM-DD'), 'Famille2');
INSERT INTO CM (id_cm, id_personnel, date_dispo, famille) VALUES (7, 17, TO_DATE('2023-06-10', 'YYYY-MM-DD'), 'Famille3');
INSERT INTO CM (id_cm, id_personnel, date_dispo, famille) VALUES (8, 18, TO_DATE('2023-10-10', 'YYYY-MM-DD'), 'Famille1');




//MySQL

INSERT INTO CM (id_cm, id_personnel, date_dispo, famille) VALUES (1, 1, '2023-06-30', 'Famille1');
INSERT INTO CM (id_cm, id_personnel, date_dispo, famille) VALUES (2, 2, '2023-08-15', 'Famille2');
INSERT INTO CM (id_cm, id_personnel, date_dispo, famille) VALUES (3, 3, '2023-07-20', 'Famille3');
INSERT INTO CM (id_cm, id_personnel, date_dispo, famille) VALUES (4, 4, '2023-09-10', 'Famille1');
INSERT INTO CM (id_cm, id_personnel, date_dispo, famille) VALUES (5, 15, '2023-07-10', 'Famille1');
INSERT INTO CM (id_cm, id_personnel, date_dispo, famille) VALUES (6, 16, '2023-07-10', 'Famille2');
INSERT INTO CM (id_cm, id_personnel, date_dispo, famille) VALUES (7, 17, '2023-06-10', 'Famille3');
INSERT INTO CM (id_cm, id_personnel, date_dispo, famille) VALUES (8, 18, '2023-10-10', 'Famille1');










/*Remplir la table Objet:

MySQL:*/


INSERT INTO Objet (id_objet, nom_objet, en_stock, prix_objet, Type) VALUES (22, 'parcland magnet', '1', 5 , 'souvenirs');
INSERT INTO Objet (id_objet, nom_objet, en_stock, prix_objet, Type) VALUES (23, 'parcland stylo', '0', 3 , 'papeterie');
INSERT INTO Objet (id_objet, nom_objet, en_stock, prix_objet, Type) VALUES (24, 'peluche simba', '1', 26 , 'peluche');
INSERT INTO Objet (id_objet, nom_objet, en_stock, prix_objet, Type) VALUES (25, 'costume princesse anna', '1', 35 , 'deguisements');
INSERT INTO Objet (id_objet, nom_objet, en_stock, prix_objet, Type) VALUES (21, 'parcland Tshirt', '1', 10 , 'souvenirs');
INSERT INTO Objet (id_objet, nom_objet, en_stock, prix_objet, Type) VALUES (20, 'peluche mickeymouse', '0', 24 , 'peluche');
INSERT INTO Objet (id_objet, nom_objet, en_stock, prix_objet, Type) VALUES (26, 'costume reine des neiges', '1', 40 , 'deguisements');


/* Oracle : */


INSERT INTO Objet (id_objet, nom_objet, en_stock, prix_objet, Type) VALUES (22, 'parcland magnet', '1', 5 , 'souvenirs');
INSERT INTO Objet (id_objet, nom_objet, en_stock, prix_objet, Type) VALUES (23, 'parcland stylo', '0', 3 , 'papeterie');
INSERT INTO Objet (id_objet, nom_objet, en_stock, prix_objet, Type) VALUES (24, 'peluche simba', '1', 26 , 'peluche');
INSERT INTO Objet (id_objet, nom_objet, en_stock, prix_objet, Type) VALUES (25, 'costume princesse anna', '1', 35 , 'deguisements');
INSERT INTO Objet (id_objet, nom_objet, en_stock, prix_objet, Type) VALUES (21, 'parcland Tshirt', '1', 10 , 'souvenirs');
INSERT INTO Objet (id_objet, nom_objet, en_stock, prix_objet, Type) VALUES (20, 'peluche mickeymouse', '0', 24 , 'peluche');
INSERT INTO Objet (id_objet, nom_objet, en_stock, prix_objet, Type) VALUES (26, 'costume reine des neiges', '1', 40 , 'deguisements');





/*Remplir la table Zone:
Mysql: */

INSERT INTO Zone (id_zone, nom_zone) VALUES (2201, 'vertigoland');
INSERT INTO Zone (id_zone, nom_zone) VALUES (2202, 'aquaticland');
INSERT INTO Zone (id_zone, nom_zone) VALUES (2203, 'adventureland');
INSERT INTO Zone (id_zone, nom_zone) VALUES (2204, 'fantasyland');

//Oracle:
INSERT INTO Zone (id_zone, nom_zone) VALUES (2201, 'vertigoland');
INSERT INTO Zone (id_zone, nom_zone) VALUES (2202, 'aquaticland');
INSERT INTO Zone (id_zone, nom_zone) VALUES (2203, 'adventureland');
INSERT INTO Zone (id_zone, nom_zone) VALUES (2204, 'fantasyland');

/*Remplir table piece :
Mysql:*/

INSERT INTO Piece (id_piece, nom_piece, quantite_piece) VALUES (201, 'plaques tournantes', 33);
INSERT INTO Piece (id_piece, nom_piece, quantite_piece) VALUES (202, 'Moteurs', 10);
INSERT INTO Piece (id_piece, nom_piece, quantite_piece) VALUES (203, 'Boîtes de vitesses', 6);
INSERT INTO Piece (id_piece, nom_piece, quantite_piece) VALUES (204, 'Volant ', 60);
INSERT INTO Piece (id_piece, nom_piece, quantite_piece) VALUES (205, 'controleur de carte ', 20);
INSERT INTO Piece (id_piece, nom_piece, quantite_piece) VALUES (206, 'boulon noir ', 50);

//oracle:

INSERT INTO Piece (id_piece, nom_piece, quantite_piece) VALUES (201, 'plaques tournantes', 33);
INSERT INTO Piece (id_piece, nom_piece, quantite_piece) VALUES (202, 'Moteurs', 10);
INSERT INTO Piece (id_piece, nom_piece, quantite_piece) VALUES (203, 'Boîtes de vitesses', 6);
INSERT INTO Piece (id_piece, nom_piece, quantite_piece) VALUES (204, 'Volant ', 60);
INSERT INTO Piece (id_piece, nom_piece, quantite_piece) VALUES (205, 'controleur de carte ', 20);
INSERT INTO Piece (id_piece, nom_piece, quantite_piece) VALUES (206, 'boulon noir ', 50);











Remplir table Manege :
Mysql:

INSERT INTO Manege (id_manege, nom_manege, description, taillemin, maintenance, famille_manege, id_zone) VALUES (10, 'big noise', 'divertissement pour les plus petits', 'pas de restriction','0','chenille',2204);

INSERT INTO Manege (id_manege, nom_manege, description, taillemin, maintenance, famille_manege, id_zone) VALUES (11, 'splash', 'aventure en famille', 'pas de restriction','1','chevaux',2203);

INSERT INTO Manege (id_manege, nom_manege, description, taillemin, maintenance, famille_manege, id_zone) VALUES (12, 'Bay Slides', 'Les toboggans à deux corps offrent des sensations réduites pour les tout-petits', '152cm','0','aquatic',2202);

INSERT INTO Manege (id_manege, nom_manege, description, taillemin, maintenance, famille_manege, id_zone) VALUES (13, 'indiana jones et le temple du péril', 'grand frissons fastpass', '140cm','1','vertigo',2201);

INSERT INTO Manege (id_manege, nom_manege, description, taillemin, maintenance, famille_manege, id_zone) VALUES (14, 'Alices curious labyrinth', 'grand frissons fastpass', 'pas de restriction','1','chenille',2204);

INSERT INTO Manege (id_manege, nom_manege, description, taillemin, maintenance, famille_manege, id_zone) VALUES (15, 'la cabane des robinsons', 'aventure en famille', 'pas de restriction','1','chevaux',2203);

INSERT INTO Manege (id_manege, nom_manege, description, taillemin, maintenance, famille_manege, id_zone) VALUES (16, 'Balade en bateau', 'divertissement pour les plus petits', 'pas de restriction','0','aquatic',2202);

INSERT INTO Manege (id_manege, nom_manege, description, taillemin, maintenance, famille_manege, id_zone) VALUES (17, 'afterburner', 'grand frissons fastpass', '140cm','1','vertigo',2201);

//Oracle:

INSERT INTO Manege (id_manege, nom_manege, description, taillemin, maintenance, famille_manege, id_zone) VALUES (10, 'big noise', 'divertissement pour les plus petits', 'pas de restriction','0','chenille',2204);

INSERT INTO Manege (id_manege, nom_manege, description, taillemin, maintenance, famille_manege, id_zone) VALUES (11, 'splash', 'aventure en famille', 'pas de restriction','1','chevaux',2203);

INSERT INTO Manege (id_manege, nom_manege, description, taillemin, maintenance, famille_manege, id_zone) VALUES (12, 'Bay Slides', 'Les toboggans à deux corps offrent des sensations réduites pour les tout-petits', '152cm','0','aquatic',2202);

INSERT INTO Manege (id_manege, nom_manege, description, taillemin, maintenance, famille_manege, id_zone) VALUES (13, 'indiana jones et le temple du péril', 'grand frissons fastpass', '140cm','1','vertigo',2201);

INSERT INTO Manege (id_manege, nom_manege, description, taillemin, maintenance, famille_manege, id_zone) VALUES (14, 'Alices curious labyrinth', 'grand frissons fastpass', 'pas de restriction','1','chenille',2204);

INSERT INTO Manege (id_manege, nom_manege, description, taillemin, maintenance, famille_manege, id_zone) VALUES (15, 'la cabane des robinsons', 'aventure en famille', 'pas de restriction','1','chevaux',2203);

INSERT INTO Manege (id_manege, nom_manege, description, taillemin, maintenance, famille_manege, id_zone) VALUES (16, 'Balade en bateau', 'divertissement pour les plus petits', 'pas de restriction','0','aquatic',2202);

INSERT INTO Manege (id_manege, nom_manege, description, taillemin, maintenance, famille_manege, id_zone) VALUES (17, 'afterburner', 'grand frissons fastpass', '140cm','1','vertigo',2201);


/*Remplissage du table Employe :
Mysql:*/

INSERT INTO Employe (id_personnel, id_employe, nom_metier, responsable_boutique, id_boutique) VALUES (9, 64,'vendeur','oui',6301);
INSERT INTO Employe (id_personnel, id_employe, nom_metier, responsable_boutique, id_boutique) VALUES (10, 65,'serveur','non',6301);
INSERT INTO Employe (id_personnel, id_employe, nom_metier, responsable_boutique, id_boutique) VALUES (11, 66,'vendeur','oui',6302);
INSERT INTO Employe (id_personnel, id_employe, nom_metier, responsable_boutique, id_boutique) VALUES (15, 67,'serveur','non',6302);
INSERT INTO Employe (id_personnel, id_employe, nom_metier, responsable_boutique, id_boutique) VALUES (17, 68,'vendeur','oui',6303);

//Oracle :
INSERT INTO Employe (id_personnel, id_employe, nom_metier, responsable_boutique, id_boutique) VALUES (9, 64,'vendeur','oui',6301);
INSERT INTO Employe (id_personnel, id_employe, nom_metier, responsable_boutique, id_boutique) VALUES (10, 65,'serveur','non',6301);
INSERT INTO Employe (id_personnel, id_employe, nom_metier, responsable_boutique, id_boutique) VALUES (11, 66,'vendeur','oui',6302);
INSERT INTO Employe (id_personnel, id_employe, nom_metier, responsable_boutique, id_boutique) VALUES (15, 67,'serveur','non',6302);
INSERT INTO Employe (id_personnel, id_employe, nom_metier, responsable_boutique, id_boutique) VALUES (17, 68,'vendeur','oui',6303);


/*Remplissage table Boutique :
Oracle:*/

INSERT INTO Boutique(id_boutique, nom_boutique, type_boutique, emplacement, CA, nb_client, id_zone) VALUES (6303, 'legends of parcland','souvenirs','adventureland',15000,550,2203);
INSERT INTO Boutique(id_boutique, nom_boutique, type_boutique, emplacement, CA, nb_client, id_zone) VALUES (6301, 'parcland food','restaurant','fantasyland',30000,900,2204);
INSERT INTO Boutique(id_boutique, nom_boutique, type_boutique, emplacement, CA, nb_client, id_zone) VALUES (6302, 'parcland coffe','cafe','fantasyland',39000,1200,2204);

//Mysql:
INSERT INTO Boutique(id_boutique, nom_boutique, type_boutique, emplacement, CA, nb_client, id_zone) VALUES (6303, 'legends of parcland','souvenirs','adventureland',15000,550,2203);
INSERT INTO Boutique(id_boutique, nom_boutique, type_boutique, emplacement, CA, nb_client, id_zone) VALUES (6301, 'parcland food','restaurant','fantasyland',30000,900,2204);
INSERT INTO Boutique(id_boutique, nom_boutique, type_boutique, emplacement, CA, nb_client, id_zone) VALUES (6302, 'parcland coffe','cafe','fantasyland',39000,1200,2204);

/*Remplissage table Vend :
Mysql:*/

INSERT INTO Vend(id_boutique, id_objet, date_vente) VALUES (6303, 22,'02/06/2023');
INSERT INTO Vend(id_boutique, id_objet, date_vente) VALUES (6303, 23,'01/06/2023');
INSERT INTO Vend(id_boutique, id_objet, date_vente) VALUES (6303, 20,'09/06/2023');
INSERT INTO Vend(id_boutique, id_objet, date_vente) VALUES (6303, 21,'01/06/2023');    

//Oracle:
INSERT INTO Vend(id_boutique, id_objet, date_vente) VALUES (6303, 22, TO_DATE('02/06/2023', 'YYYY-MM-DD') );
INSERT INTO Vend(id_boutique, id_objet, date_vente) VALUES (6303, 23, TO_DATE('01/06/2023', 'YYYY-MM-DD') );
INSERT INTO Vend(id_boutique, id_objet, date_vente) VALUES (6303, 20, TO_DATE('09/06/2023', 'YYYY-MM-DD') );
INSERT INTO Vend(id_boutique, id_objet, date_vente) VALUES (6303, 21, TO_DATE('01/06/2023', 'YYYY-MM-DD') );                 


/*Remplissage table technicien :
Mysql :*/
INSERT INTO Technicien (id_personnel, id_technicien, responsable_atelier, id_atelier) VALUES (12, 80, '1', 101);
INSERT INTO Technicien (id_personnel, id_technicien, responsable_atelier, id_atelier) VALUES (13, 81, '1', 102);
INSERT INTO Technicien (id_personnel, id_technicien, responsable_atelier, id_atelier) VALUES (14, 82, '1', 103);
INSERT INTO Technicien (id_personnel, id_technicien, responsable_atelier, id_atelier) VALUES (16, 83,'1', 104);

//Oracle:

INSERT INTO Technicien (id_personnel, id_technicien, responsable_atelier, id_atelier) VALUES (12, 80, '1', 101);
INSERT INTO Technicien (id_personnel, id_technicien, responsable_atelier, id_atelier) VALUES (13, 81, '1', 102);
INSERT INTO Technicien (id_personnel, id_technicien, responsable_atelier, id_atelier) VALUES (14, 82, '1', 103);
INSERT INTO Technicien (id_personnel, id_technicien, responsable_atelier, id_atelier) VALUES (16, 83,'1', 104);


/*Remplissage table Atelier :
Mysql :*/

INSERT INTO Atelier (id_atelier, nom_atelier, id_zone) VALUES (101, 'verti_at',2201);
INSERT INTO Atelier (id_atelier, nom_atelier, id_zone) VALUES (102,'aqua_at',2202);
INSERT INTO Atelier (id_atelier, nom_atelier, id_zone) VALUES (103, 'adven_at',2203);
INSERT INTO Atelier (id_atelier, nom_atelier, id_zone) VALUES (104, 'fanta_at',2204);

//Oracle:

INSERT INTO Atelier (id_atelier, nom_atelier, id_zone) VALUES (101, 'verti_at',2201);
INSERT INTO Atelier (id_atelier, nom_atelier, id_zone) VALUES (102,'aqua_at',2202);
INSERT INTO Atelier (id_atelier, nom_atelier, id_zone) VALUES (103, 'adven_at',2203);
INSERT INTO Atelier (id_atelier, nom_atelier, id_zone) VALUES (104, 'fanta_at',2204);Remplissage table Stock :
//Mysql: 

INSERT INTO Stock (id_atelier, id_piece, quantite) VALUES (101, 201, 33);

INSERT INTO Stock (id_atelier, id_piece, quantite) VALUES (102, 204, 60);

INSERT INTO Stock (id_atelier, id_piece, quantite) VALUES (103, 203, 6);

INSERT INTO Stock (id_atelier, id_piece, quantite) VALUES (104, 206, 50);

//Oracle:

INSERT INTO Stock (id_atelier, id_piece, quantite) VALUES (101, 201, 33);

INSERT INTO Stock (id_atelier, id_piece, quantite) VALUES (102, 204, 60);

INSERT INTO Stock (id_atelier, id_piece, quantite) VALUES (103, 203, 6);

INSERT INTO Stock (id_atelier, id_piece, quantite) VALUES (104, 206, 50);


/*Remplissage de table Nb_client 
Mysql : */

INSERT INTO Nb_client (id_manege, id_nbclient, nombre_client_demijournee, date_enregistrement, demi_journee) VALUES (10, 5000, 300,'01/06/2023',01);

INSERT INTO Nb_client (id_manege, id_nbclient, nombre_client_demijournee, date_enregistrement, demi_journee) VALUES (11, 5100, 460,'02/06/2023',02);

INSERT INTO Nb_client (id_manege, id_nbclient, nombre_client_demijournee, date_enregistrement, demi_journee) VALUES (12, 5200, 350,'03/06/2023',03);

INSERT INTO Nb_client (id_manege, id_nbclient, nombre_client_demijournee, date_enregistrement, demi_journee) VALUES (13, 5300, 560,'04/06/2023',04);

INSERT INTO Nb_client (id_manege, id_nbclient, nombre_client_demijournee, date_enregistrement, demi_journee) VALUES (14, 5400, 880,'05/06/2023',05);

INSERT INTO Nb_client (id_manege, id_nbclient, nombre_client_demijournee, date_enregistrement, demi_journee) VALUES (15, 5500, 876,'06/06/2023',06);

INSERT INTO Nb_client (id_manege, id_nbclient, nombre_client_demijournee, date_enregistrement, demi_journee) VALUES (16, 5600, 900,'07/06/2023',07); 

INSERT INTO Nb_client (id_manege, id_nbclient, nombre_client_demijournee, date_enregistrement, demi_journee) VALUES (17, 5700, 897,'08/06/2023',08);


//Oracle :

INSERT INTO Nb_client (id_manege, id_nbclient, nombre_client_demijournee, date_enregistrement, demi_journee) VALUES (10, 5000, 300,TO_DATE('01/06/2023', 'YYYY-MM-DD'),01);

INSERT INTO Nb_client (id_manege, id_nbclient, nombre_client_demijournee, date_enregistrement, demi_journee) VALUES (11, 5100, 460,TO_DATE('02/06/2023', 'YYYY-MM-DD'),02);

INSERT INTO Nb_client (id_manege, id_nbclient, nombre_client_demijournee, date_enregistrement, demi_journee) VALUES (12, 5200, 350,TO_DATE('03/06/2023', 'YYYY-MM-DD'),03);

INSERT INTO Nb_client (id_manege, id_nbclient, nombre_client_demijournee, date_enregistrement, demi_journee) VALUES (13, 5300, 560,TO_DATE('04/06/2023', 'YYYY-MM-DD'),04);

INSERT INTO Nb_client (id_manege, id_nbclient, nombre_client_demijournee, date_enregistrement, demi_journee) VALUES (14, 5400, 880,TO_DATE('05/06/2023', 'YYYY-MM-DD'),05);

INSERT INTO Nb_client (id_manege, id_nbclient, nombre_client_demijournee, date_enregistrement, demi_journee) VALUES (15, 5500, 876,TO_DATE('06/06/2023', 'YYYY-MM-DD'),06);

INSERT INTO Nb_client (id_manege, id_nbclient, nombre_client_demijournee, date_enregistrement, demi_journee) VALUES (16, 5600, 900,TO_DATE('07/06/2023', 'YYYY-MM-DD'),07); 

INSERT INTO Nb_client (id_manege, id_nbclient, nombre_client_demijournee, date_enregistrement, demi_journee) VALUES (17, 5700, 897,TO_DATE('08/06/2023', 'YYYY-MM-DD'),08);



/*Remplissage table Remplace : 
Mysql :*/
 
INSERT INTO Remplace (id_personnel_est_remplace,id_cm_est_remplace, id_personnel_remplace, id_cm_remplace, date_remplacement) VALUES (1, 1, 4,4,'11/11/2023');
INSERT INTO Remplace (id_personnel_est_remplace,id_cm_est_remplace, id_personnel_remplace, id_cm_remplace, date_remplacement) VALUES (2, 2, 1,1,'30/06/2023');

//Oracle :
INSERT INTO Remplace (id_personnel_est_remplace,id_cm_est_remplace, id_personnel_remplace, id_cm_remplace, date_remplacement) VALUES (1, 1, 4,4,TO_DATE('11/11/2023', 'YYYY-MM-DD'));

INSERT INTO Remplace (id_personnel_est_remplace,id_cm_est_remplace, id_personnel_remplace, id_cm_remplace, date_remplacement) VALUES (2, 2, 1,1,TO_DATE('30/06/2023', 'YYYY-MM-DD'));



/*Remplissage table reparation :
Oracle :*/

INSERT INTO Reparation (id_manege, id_personnel, id_technicien, id_piece, date_reparation) VALUES (13, 12, 81,203,TO_DATE('12/03/2022', 'YYYY-MM-DD'));
INSERT INTO Reparation (id_manege, id_personnel, id_technicien, id_piece, date_reparation) VALUES (16, 13, 82,204,TO_DATE('25/09/2023', 'YYYY-MM-DD'));

//Mysql:

INSERT INTO Reparation (id_manege, id_personnel, id_technicien, id_piece, date_reparation) VALUES (13, 12, 81,203,'12/03/2022');
INSERT INTO Reparation (id_manege, id_personnel, id_technicien, id_piece, date_reparation) VALUES (16, 13, 82,204,'25/09/2023');

/*remplissage table directeur 
sql */

INSERT INTO Directeur ('id_personnel', 'id_directeur') VALUES (18, 22016308);

//oracle 
INSERT INTO Directeur ('id_personnel', 'id_directeur') VALUES (18, 22016308);

/*Remplissage table En_charge :
Mysql: */

INSERT INTO Prend_encharge (id_manege, id_personnel, id_cm, date_encharge) VALUES (10, 1,1, '2023-06-30');
INSERT INTO Prend_encharge (id_manege, id_personnel, id_cm, date_encharge) VALUES (11, 2,3, '2023-08-15');
INSERT INTO Prend_encharge (id_manege, id_personnel, id_cm, date_encharge) VALUES (12, 3,3, '2023-07-20');
INSERT INTO Prend_encharge (id_manege, id_personnel, id_cm, date_encharge) VALUES (13, 4,4, '2023-09-10');
INSERT INTO Prend_encharge (id_manege, id_personnel, id_cm, date_encharge) VALUES (14, 15,5, '2023-07-10');
INSERT INTO Prend_encharge (id_manege, id_personnel, id_cm, date_encharge) VALUES (15, 16,6, '2023-07-10');
INSERT INTO Prend_encharge (id_manege, id_personnel, id_cm, date_encharge) VALUES (16, 17,7, '2023-07-10');
INSERT INTO Prend_encharge (id_manege, id_personnel, id_cm, date_encharge) VALUES (17, 18,8, '2023-10-10');


//Oracle:


INSERT INTO Prend_encharge (id_manege, id_personnel, id_cm, date_encharge) VALUES (10, 1,1, TO_DATE('2023-06-30', 'YYYY-MM-DD'));

INSERT INTO Prend_encharge (id_manege, id_personnel, id_cm, date_encharge) VALUES (11, 2,3, TO_DATE('2023-08-15', 'YYYY-MM-DD'));
INSERT INTO Prend_encharge (id_manege, id_personnel, id_cm, date_encharge) VALUES (12, 3,3, TO_DATE('2023-07-20', 'YYYY-MM-DD'));
INSERT INTO Prend_encharge (id_manege, id_personnel, id_cm, date_encharge) VALUES (13, 4,4, TO_DATE('2023-09-10', 'YYYY-MM-DD'));
INSERT INTO Prend_encharge (id_manege, id_personnel, id_cm, date_encharge) VALUES (14, 15,5, TO_DATE('2023-07-10', 'YYYY-MM-DD'));
INSERT INTO Prend_encharge (id_manege, id_personnel, id_cm, date_encharge) VALUES (15, 16,6, TO_DATE('2023-07-10', 'YYYY-MM-DD'));
INSERT INTO Prend_encharge (id_manege, id_personnel, id_cm, date_encharge) VALUES (16, 17,7, TO_DATE('2023-07-10', 'YYYY-MM-DD'));
INSERT INTO Prend_encharge (id_manege, id_personnel, id_cm, date_encharge) VALUES (17, 18,8, TO_DATE('2023-10-10', 'YYYY-MM-DD'));
